# Version 1.3.2
- Reimplemented OnMapInit()

# Version 1.3.1
- Changed Default Timestamp value to a valid strirng

# Version 1.3.0
- Added UIFramework support
- Added timestamp file feature
- Rumble 0.5.x.x support

# Version 1.2.0
- Added folder creation and relative file path support in auto-rename string
- Deprecated Replay Buffer Prefix in favor of using its own independent auto-rename string
- Added map support in file names

# Version 1.1.0
- Added config options for positioning OBS icon along healthbar

# Version 1.0.0
- Created